from flask import Flask, request, redirect, url_for, render_template
from azure.storage.blob import BlobServiceClient
import uuid
import os
from upload_file import upload_file
app = Flask(__name__)

# Substitua pela sua connection string


# Inicializando o cliente do Blob Service


@app.route('/')
def index():
    return render_template('upload.html')

@app.route('/upload', methods=['POST'])
def upload_file2():

    file = request.files['file']
    link_arquivo = upload_file(file)

    return link_arquivo, 200

if __name__ == '__main__':
    app.run(debug=True)